<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Volcano BG" tilewidth="1280" tileheight="704" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="1280" height="192" source="../Volcano_Pack_1.1/bg_volcano_1.png"/>
 </tile>
 <tile id="1">
  <image width="1280" height="293" source="../Volcano_Pack_1.1/bg_volcano_2.png"/>
 </tile>
 <tile id="2">
  <image width="1280" height="329" source="../Volcano_Pack_1.1/bg_volcano_3.png"/>
 </tile>
 <tile id="3">
  <image width="1280" height="428" source="../Volcano_Pack_1.1/bg_volcano_4.png"/>
 </tile>
 <tile id="4">
  <image width="1280" height="177" source="../Volcano_Pack_1.1/bg_volcano_5.png"/>
 </tile>
 <tile id="6">
  <image width="1280" height="704" source="../Volcano_Pack_1.1/bg_volcano_6.png"/>
 </tile>
</tileset>
