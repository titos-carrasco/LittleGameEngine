<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Volcano" tilewidth="128" tileheight="256" tilecount="53" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="60">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_03.png"/>
 </tile>
 <tile id="61">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_05.png"/>
 </tile>
 <tile id="62">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_07.png"/>
 </tile>
 <tile id="63">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_09.png"/>
 </tile>
 <tile id="64">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_11.png"/>
 </tile>
 <tile id="65">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_13.png"/>
 </tile>
 <tile id="66">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_15.png"/>
 </tile>
 <tile id="67">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_17.png"/>
 </tile>
 <tile id="68">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_19.png"/>
 </tile>
 <tile id="69">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_21.png"/>
 </tile>
 <tile id="70">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_33.png"/>
 </tile>
 <tile id="71">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_34.png"/>
 </tile>
 <tile id="72">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_35.png"/>
 </tile>
 <tile id="73">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_36.png"/>
 </tile>
 <tile id="74">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_37.png"/>
 </tile>
 <tile id="75">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_38.png"/>
 </tile>
 <tile id="76">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_39.png"/>
 </tile>
 <tile id="77">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_40.png"/>
 </tile>
 <tile id="78">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_41.png"/>
 </tile>
 <tile id="79">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_51.png"/>
 </tile>
 <tile id="80">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_52.png"/>
 </tile>
 <tile id="81">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_53.png"/>
 </tile>
 <tile id="82">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_54.png"/>
 </tile>
 <tile id="83">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_56.png"/>
 </tile>
 <tile id="84">
  <image width="128" height="256" source="../Volcano_Pack_1.1/volcano_pack_59.png"/>
 </tile>
 <tile id="85">
  <image width="128" height="129" source="../Volcano_Pack_1.1/volcano_pack_65.png"/>
 </tile>
 <tile id="86">
  <image width="128" height="129" source="../Volcano_Pack_1.1/volcano_pack_66.png"/>
 </tile>
 <tile id="87">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_68.png"/>
 </tile>
 <tile id="88">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_69.png"/>
 </tile>
 <tile id="89">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_70.png"/>
 </tile>
 <tile id="90">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_71.png"/>
 </tile>
 <tile id="91">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_72.png"/>
 </tile>
 <tile id="92">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_73.png"/>
 </tile>
 <tile id="93">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_74.png"/>
 </tile>
 <tile id="94">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_03.png"/>
 </tile>
 <tile id="95">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_05.png"/>
 </tile>
 <tile id="96">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_07.png"/>
 </tile>
 <tile id="97">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_09.png"/>
 </tile>
 <tile id="98">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_11.png"/>
 </tile>
 <tile id="99">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_13.png"/>
 </tile>
 <tile id="100">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_15.png"/>
 </tile>
 <tile id="101">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_17.png"/>
 </tile>
 <tile id="102">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_19.png"/>
 </tile>
 <tile id="103">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_21.png"/>
 </tile>
 <tile id="104">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_33.png"/>
 </tile>
 <tile id="105">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_34.png"/>
 </tile>
 <tile id="106">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_35.png"/>
 </tile>
 <tile id="107">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_36.png"/>
 </tile>
 <tile id="108">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_37.png"/>
 </tile>
 <tile id="109">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_38.png"/>
 </tile>
 <tile id="110">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_39.png"/>
 </tile>
 <tile id="111">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_40.png"/>
 </tile>
 <tile id="112">
  <image width="128" height="128" source="../Volcano_Pack_1.1/volcano_pack_alt_41.png"/>
 </tile>
</tileset>
