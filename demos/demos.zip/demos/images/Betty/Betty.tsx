<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Betty" tilewidth="32" tileheight="32" tilecount="17" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="down-001.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="down-002.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="down-003.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="32" source="down-004.png"/>
 </tile>
 <tile id="4">
  <image width="32" height="32" source="left-001.png"/>
 </tile>
 <tile id="5">
  <image width="32" height="32" source="left-002.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="32" source="left-003.png"/>
 </tile>
 <tile id="7">
  <image width="32" height="32" source="left-004.png"/>
 </tile>
 <tile id="8">
  <image width="32" height="32" source="right-001.png"/>
 </tile>
 <tile id="9">
  <image width="32" height="32" source="right-002.png"/>
 </tile>
 <tile id="10">
  <image width="32" height="32" source="right-003.png"/>
 </tile>
 <tile id="11">
  <image width="32" height="32" source="right-004.png"/>
 </tile>
 <tile id="12">
  <image width="32" height="32" source="up-001.png"/>
 </tile>
 <tile id="13">
  <image width="32" height="32" source="up-002.png"/>
 </tile>
 <tile id="14">
  <image width="32" height="32" source="up-003.png"/>
 </tile>
 <tile id="15">
  <image width="32" height="32" source="up-004.png"/>
 </tile>
 <tile id="16">
  <properties>
   <property name="name" value="muro"/>
  </properties>
  <image width="32" height="32" source="Bloque.png"/>
 </tile>
</tileset>
